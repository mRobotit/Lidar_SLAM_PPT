# gazebo_models
Some house models are designed forgazebo.


usage

models文件是需要放在/.gazebo下的models文件下的，worlds文件可以直接用launch加载或者用gazebo打开。
